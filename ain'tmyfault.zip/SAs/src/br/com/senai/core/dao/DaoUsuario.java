package br.com.senai.core.dao;

import br.com.senai.core.domain.Usuario;

public interface DaoUsuario {
	public Usuario autenticar(Usuario usuario);
	
}
