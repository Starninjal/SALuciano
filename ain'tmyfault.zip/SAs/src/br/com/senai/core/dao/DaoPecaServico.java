package br.com.senai.core.dao;

public interface DaoPecaServico {

}
