package br.com.senai.core.dao.postgresql;

import br.com.senai.core.dao.DaoPecaServico;

public class DaoPostgresqlPecaServico implements DaoPecaServico{

}
