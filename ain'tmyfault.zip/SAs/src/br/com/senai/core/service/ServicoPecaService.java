package br.com.senai.core.service;

import br.com.senai.core.dao.DaoPecaServico;

public class ServicoPecaService {
	private DaoPecaServico dao;
	
	public ServicoPecaService() {
		
	}
	
	
}
