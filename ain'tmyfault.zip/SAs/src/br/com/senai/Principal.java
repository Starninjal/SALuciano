package br.com.senai;

import br.com.senai.view.ViewOrdemServico;

public class Principal{
	public static void main(String[] args) {
		new ViewOrdemServico().setVisible(true);
	}
}
